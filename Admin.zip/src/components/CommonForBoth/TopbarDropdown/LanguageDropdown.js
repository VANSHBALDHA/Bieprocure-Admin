import React from 'react'

const LanguageDropdown = () => {
  return (
    <div>LanguageDropdown</div>
  )
}

export default LanguageDropdown